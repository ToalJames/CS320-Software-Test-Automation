package Task;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * TaskServiceTest.java
 * Unit tests for the TaskService class to verify business logic requirements.
 */
class TaskServiceTest {
    private TaskService service;

    /**
     * Re-initializes the service before each test to ensure a clean state.
     */
    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    /**
     * Verifies that a task can be successfully added to the in-memory structure.
     */
    @Test
    void testAddTask() {
        Task task = new Task("1", "Name", "Desc");
        service.addTask(task);
        assertNotNull(service.getTask("1")); // Confirms the task is retrievable
    }

    /**
     * Verifies the requirement that each task must have a unique ID.
     */
    @Test
    void testAddDuplicateId() {
        Task task1 = new Task("1", "Name", "Desc");
        Task task2 = new Task("1", "Other", "Other");
        service.addTask(task1);
        // Requirement: Adding a duplicate ID must throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
    }

    /**
     * Verifies that a task can be deleted based on its specific Task ID.
     */
    @Test
    void testDeleteTask() {
        Task task = new Task("1", "Name", "Desc");
        service.addTask(task);
        service.deleteTask("1");
        assertNull(service.getTask("1")); // Confirms the task no longer exists
    }

    /**
     * Verifies that Task fields (Name and Description) can be updated.
     */
    @Test
    void testUpdateTask() {
        Task task = new Task("1", "Old Name", "Old Desc");
        service.addTask(task);
        
        // Requirement: Service must support updating Name and Description fields
        service.updateTask("1", "New Name", "New Desc");
        
        assertEquals("New Name", service.getTask("1").getName());
        assertEquals("New Desc", service.getTask("1").getDescription());
    }
    void testUpdateTaskNotFound() {
        // Attempting to update an ID that was never added
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateTask("999", "Name", "Desc")
        );
    }
}