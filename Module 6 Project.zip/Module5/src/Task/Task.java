package Task;
/**
 * Task.java
 * Represents a task object with validation for ID, name, and description.
 */
public class Task {
    // Fields must be private according to standard Java encapsulation
    private final String taskId; // final because the ID shall not be updatable
    private String name;
    private String description;

    /**
     * Constructor for the Task object.
     * Validates all input fields based on project requirements.
     */
    public Task(String taskId, String name, String description) {
        // Validation: Task ID must not be null and cannot be longer than 10 characters
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }
        // Validation: Name must not be null and cannot be longer than 20 characters
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        // Validation: Description must not be null and cannot be longer than 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }
        
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Accessor (Getter) methods
    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    /**
     * Updates the task name with validation.
     */
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        this.name = name;
    }

    /**
     * Updates the task description with validation.
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }
        this.description = description;
    }
}