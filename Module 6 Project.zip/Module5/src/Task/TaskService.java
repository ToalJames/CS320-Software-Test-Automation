package Task;
import java.util.ArrayList;
import java.util.List;

/**
 * TaskService.java
 * Manages a collection of Task objects in memory.
 * Provides functionality to add, delete, and update tasks by unique ID.
 */
public class TaskService {
    // Requirement: Use an in-memory data structure (ArrayList)
    private final List<Task> tasks = new ArrayList<>();

    /**
     * Adds a new task to the list if the ID is unique.
     * @param task The Task object to add.
     */
    public void addTask(Task task) {
        // Requirement: Ensure each task has a unique ID
        for (Task t : tasks) {
            if (t.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID already exists");
            }
        }
        tasks.add(task);
    }

    /**
     * Deletes a task from the list based on its Task ID.
     * @param taskId The unique ID of the task to be removed.
     */
    public void deleteTask(String taskId) {
        // Requirement: Ability to delete tasks per task ID
        tasks.removeIf(t -> t.getTaskId().equals(taskId));
    }

    /**
     * Updates the name and description of an existing task.
     * @param taskId The unique ID of the task to update.
     * @param name The new name for the task.
     * @param description The new description for the task.
     */
    public void updateTask(String taskId, String name, String description) {
        // Requirement: Ability to update task fields (Name and Description)
        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) {
                t.setName(name);
                t.setDescription(description);
                return;
            }
        }
        // Requirement: Provide error handling if task is not found
        throw new IllegalArgumentException("Task not found");
    }

    /**
     * Helper method to retrieve a task by ID.
     * Useful for verification and unit testing.
     */
    public Task getTask(String taskId) {
        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) return t;
        }
        return null;
    }
}