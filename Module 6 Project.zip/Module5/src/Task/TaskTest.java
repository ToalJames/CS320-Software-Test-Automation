package Task;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * TaskTest.java
 * Unit tests for the Task object to verify data validation rules.
 */
class TaskTest {
    
    /**
     * Verifies that a task is created correctly when all inputs meet requirements.
     */
    @Test
    void testTaskCreationSuccess() {
        Task task = new Task("12345", "Name", "Description");
        assertEquals("12345", task.getTaskId());
        assertEquals("Name", task.getName());
        assertEquals("Description", task.getDescription());
    }

    /**
     * Verifies that an exception is thrown if the Task ID exceeds 10 characters.
     */
    @Test
    void testTaskIdTooLong() {
        // Requirement: ID cannot be longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc"));
    }

    /**
     * Verifies that an exception is thrown if the Name exceeds 20 characters.
     */
    @Test
    void testTaskNameTooLong() {
        // Requirement: Name cannot be longer than 20 characters
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "This name is much too long", "Desc"));
    }

    /**
     * Verifies that an exception is thrown if the Description exceeds 50 characters.
     */
    @Test
    void testTaskDescriptionTooLong() {
        // Requirement: Description cannot be longer than 50 characters
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", "This description is definitely over the fifty character limit."));
    }
    @Test
    void testTaskNullValues() {
        // Test null ID
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        // Test null Name
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Desc"));
        // Test null Description
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", null));
    }

    @Test
    void testSettersSuccess() {
        Task task = new Task("1", "Name", "Desc");
        task.setName("New Name");
        task.setDescription("New Description");
        assertEquals("New Name", task.getName());
        assertEquals("New Description", task.getDescription());
    }
}