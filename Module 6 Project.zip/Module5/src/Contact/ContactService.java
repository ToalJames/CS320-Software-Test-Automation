package Contact;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    
    // Store contacts in a Map for easy lookup by ID
    private final Map<String, Contact> contacts = new HashMap<>();

    // Adds a contact only if the ID isn't already in the Map
    public void addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("ID already exists or contact is null");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Finds the ID in the Map and removes it
    public void deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Cannot find ID to delete");
        }
        contacts.remove(contactId);
    }

    // Update first name - throws error if ID doesn't exist
    public void updateFirstName(String contactId, String firstName) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("ID not found for update");
        }
        contacts.get(contactId).setFirstName(firstName);
    }

    // Update last name - uses setter from Contact class
    public void updateLastName(String contactId, String lastName) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("ID not found for update");
        }
        contacts.get(contactId).setLastName(lastName);
    }

    // Update phone - must be exactly 10 digits (checked in Contact.java)
    public void updateNumber(String contactId, String phone) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("ID not found for update");
        }
        contacts.get(contactId).setPhone(phone);
    }

    // Update address - must be 30 chars or less
    public void updateAddress(String contactId, String address) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("ID not found for update");
        }
        contacts.get(contactId).setAddress(address);
    }
}