package Contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    // Test adding a contact successfully
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact c1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(c1);
        
        // If it doesn't throw an error, it passed. We can verify with a getter if needed.
        assertNotNull(c1.getContactId());
    }

    // Test that adding a duplicate ID throws an error
    @Test
    public void testAddDuplicateId() {
        ContactService service = new ContactService();
        Contact c1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        Contact c2 = new Contact("1", "Jane", "Smith", "0987654321", "456 Oak Ave");
        
        service.addContact(c1);
        
        // This should trigger the IllegalArgumentException I coded earlier
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(c2);
        });
    }

    // Test deleting a contact
    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact c1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(c1);
        
        service.deleteContact("1");
        
        // Try to delete it again - should fail because it's gone
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("1");
        });
    }

    // Test updating the phone number
    @Test
    public void testUpdatePhoneNumber() {
        ContactService service = new ContactService();
        Contact c1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(c1);
        
        service.updateNumber("1", "5555555555");
        assertEquals("5555555555", c1.getPhone());
    }

    // Test update fails if ID is wrong
    @Test
    public void testUpdateInvalidId() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99", "NewName");
        });
    }
    // Test adding a null contact
    @Test
    public void testAddNullContact() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }

    // Test that other update methods also throw errors for invalid IDs
    @Test
    public void testAllUpdatesInvalidId() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("99", "Doe"));
        assertThrows(IllegalArgumentException.class, () -> service.updateNumber("99", "1234567890"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("99", "123 Main St"));
    }
}