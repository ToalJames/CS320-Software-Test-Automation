package Contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // Test that a valid contact is created without errors
    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertTrue(contact.getContactId().equals("12345"));
        assertTrue(contact.getFirstName().equals("John"));
        assertTrue(contact.getLastName().equals("Doe"));
        assertTrue(contact.getPhone().equals("1234567890"));
        assertTrue(contact.getAddress().equals("123 Main St"));
    }

    // Test that ID is too long (over 10 chars)
    @Test
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "Address");
        });
    }

    // Test that first name is null
    @Test
    public void testContactFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", null, "Doe", "1234567890", "Address");
        });
    }

    // Test that phone number is not exactly 10 digits
    @Test
    public void testContactPhoneInvalidLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Doe", "123456789", "Address"); // 9 digits
        });
    }

    // Test that phone number contains non-digits
    @Test
    public void testContactPhoneNotDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Doe", "123abc7890", "Address");
        });
    }

    // Test that address is too long (over 30 chars)
    @Test
    public void testContactAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Doe", "1234567890", "1234567890123456789012345678901");
        });
    }
    @Test
    public void testContactSettersSuccess() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("0987654321");
        contact.setAddress("456 Oak Ave");
        
        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("456 Oak Ave", contact.getAddress());
    }

    // Test that setters still enforce validation
    @Test
    public void testContactSettersInvalid() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123")); // Too short
    }
}