package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appt = new Appointment("1", futureDate, "Initial Description");
        
        service.addAppointment(appt);
        // Ensure the map now contains the new ID
        assertTrue(service.getAppointments().containsKey("1"));
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appt = new Appointment("1", futureDate, "Description");
        
        service.addAppointment(appt);
        service.deleteAppointment("1");
        // Ensure the ID was removed successfully
        assertFalse(service.getAppointments().containsKey("1"));
    }

    @Test
    void testUpdateAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appt = new Appointment("1", futureDate, "Original Description");
        service.addAppointment(appt);
        
        Date newDate = new Date(System.currentTimeMillis() + 172800000);
        String newDesc = "Updated Description Content";
        
        service.updateAppointment("1", newDate, newDesc);
        // Verify changes reflect in the stored object
        assertEquals(newDesc, service.getAppointments().get("1").getDescription());
        assertEquals(newDate, service.getAppointments().get("1").getAppointmentDate());
    }

    @Test
    void testDuplicateIdError() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appt1 = new Appointment("1", futureDate, "Desc");
        Appointment appt2 = new Appointment("1", futureDate, "Desc");
        
        service.addAppointment(appt1);
        // Catch duplicate entry attempt
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }

    @Test
    void testUpdateInvalidId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        
        // Catch update attempt on non-existent record
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAppointment("999", futureDate, "New Description");
        });
    }
    @Test
    void testAddNullAppointment() {
        AppointmentService service = new AppointmentService();
        // Catch attempt to add a null object
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }

    @Test
    void testDeleteInvalidId() {
        AppointmentService service = new AppointmentService();
        // Catch attempt to delete an ID that doesn't exist
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}