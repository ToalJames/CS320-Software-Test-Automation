package appointment;

import java.util.HashMap;
import java.util.Map;
import java.util.Date;

public class AppointmentService {
    // Map used for in-memory storage of appointment objects
    private final Map<String, Appointment> appointmentMap = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        // Prevent null appointments and ensure IDs are unique
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment object cannot be null.");
        }
        
        if (appointmentMap.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Duplicate ID: Appointment ID must be unique.");
        }
        
        appointmentMap.put(appointment.getAppointmentId(), appointment);
    }

    public void deleteAppointment(String appointmentId) {
        // Check for existence before attempting to remove
        if (appointmentId == null || !appointmentMap.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Delete failed: Appointment ID not found.");
        }
        
        appointmentMap.remove(appointmentId);
    }

    public void updateAppointment(String id, Date newDate, String newDesc) {
        // Confirm the record exists prior to update
        if (id == null || !appointmentMap.containsKey(id)) {
            throw new IllegalArgumentException("Update failed: Appointment ID not found.");
        }
        
        // Replacing the object ensures new data is validated by the Appointment constructor
        Appointment updatedAppt = new Appointment(id, newDate, newDesc);
        appointmentMap.put(id, updatedAppt);
    }

    // Accessor to help with unit test verification
    public Map<String, Appointment> getAppointments() {
        return appointmentMap;
    }
}