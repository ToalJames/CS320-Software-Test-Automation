package appointment;

import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Enforce ID length and null constraints
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid ID: Must be non-null and max 10 characters.");
        }
        
        // Ensure date is provided and not set in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid Date: Must be non-null and not in the past.");
        }
        
        // Check description length and nullity
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid Description: Must be non-null and max 50 characters.");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() { return appointmentId; }
    public Date getAppointmentDate() { return appointmentDate; }
    public String getDescription() { return description; }
}