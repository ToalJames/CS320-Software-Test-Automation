package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    // Standard helper for a valid future date
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    @Test
    void testAppointmentCreationSuccess() {
        Appointment appt = new Appointment("12345", getFutureDate(), "Doctor visit");
        // Confirm all fields are correctly initialized
        assertEquals("12345", appt.getAppointmentId());
        assertEquals("Doctor visit", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    @Test
    void testAppointmentIdValidation() {
        // Fail if ID exceeds 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Description");
        });
        // Fail if ID is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Description");
        });
    }

    @Test
    void testAppointmentDateValidation() {
        // Fail if date is in the past
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Description");
        });
        // Fail if date is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", null, "Description");
        });
    }

    @Test
    void testAppointmentDescriptionValidation() {
        // Fail if description is too long
        String longDesc = "This description is much too long for the limit of 50 characters.";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", getFutureDate(), longDesc);
        });
        // Fail if description is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", getFutureDate(), null);
        });
    }
    @Test
    void testAppointmentDateInPast() {
        // Test a date that is just barely in the past (1 minute ago)
        Date barelyPast = new Date(System.currentTimeMillis() - 60000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", barelyPast, "Description");
        });
    }

    @Test
    void testGetters() {
        Date date = getFutureDate();
        Appointment appt = new Appointment("123", date, "Desc");
        
        // Assertions for every getter to ensure 100% coverage
        assertEquals("123", appt.getAppointmentId());
        assertEquals(date, appt.getAppointmentDate());
        assertEquals("Desc", appt.getDescription());
    }
}